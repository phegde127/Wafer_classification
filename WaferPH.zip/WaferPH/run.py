import trainingModel_ph

trainObj = trainingModel_ph.trainModel()
trainObj.trainingModel()