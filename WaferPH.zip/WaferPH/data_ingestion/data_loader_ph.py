import pandas as pd

class Data_Getter:
    """
    This class shall be used to obtain the data from the source directory for training
    
    Written by: Pradeep Hegde
    Version: 1.0
    Revision: 0.1

    """
    def __init__(self, file_object, logger_object):
        self.training_file = "Training_FileFromDB/InputFile.csv"
        self.file_object = file_object
        self.logger_object = logger_object
       
    def get_data(self):
        """
        Method name: get_data
        Description: This method is used to read data from the source
        Output: This method outputs a pandas dataframe
        On failure: Raise exception
        
        Written by: Pradeep Hegde
        Version: 1.0
        Revision: 0.1
        
        """
        self.logger_object.log(self.file_object, 'Entered the get_data method of the Data_Getter class')
        try:
            self.data = pd.read_csv(self.training_file) #Readin the data file as dataframe
            self.logger_object.log(self.file_object,'Data load successful. Exited the get_data method of the Data_Getter class')
            return self.data
        except Exception as e:
            self.logger_object.log(self.file_object,'Exception occured in get_data method of the Data_Getter class. Exception message: '+str(e))
            self.logger_object.log(self.file_object,
                                   'Data Load Unsuccessful.Exited the get_data method of the Data_Getter class')
            raise Exception()